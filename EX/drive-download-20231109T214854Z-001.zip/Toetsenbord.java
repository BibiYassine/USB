import java.math.BigDecimal;

public class Toetsenbord {
    private String serienummer;
    private String merk;
    private boolean draadloos;
    private BigDecimal prijs;
    private ToetsenbordLayout

    public void setMerk(String merk) {
        this.merk = merk;
    }
    public String getMerk() {
        return merk;
    }

    public boolean isDraadloos() {
        return draadloos;
    }

    public void setDraadloos(boolean draadloos) {
        this.draadloos = draadloos;
    }

    public BigDecimal getPrijs() {
        return prijs;
    }

    public void setPrijs(BigDecimal prijs) {
        this.prijs = prijs;
    }

    public String getSerienummer() {
        return serienummer;
    }

    public void setSerienummer(String serienummer) {
        this.serienummer = serienummer;
    }
}

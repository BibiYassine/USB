import java.util.Scanner;

public class ${NAME} {
    public static void main(String[] args) {
        Scanner invoer = new Scanner(System.in);
        //variable
        int persoon1;
        int persoon2;
        //invoer
        System.out.print("Geef de leeftijd van persoon 1: ");
        persoon1 =invoer.nextInt();
        System.out.println("Geef de leeftijd van persoon 2: ");
        persoon2 = invoer.nextInt();
        //if statement
        if (persoon1 / 3 > persoon2) {
            System.out.println("Persoon 1 is meer dan drie maal zo oud als persoon 2");
        } else if (persoon1 / 2 > persoon2) {
            System.out.println("persoon 1 is meer dan 2 maal zo oud als persoon 2");
        }else if (persoon1 > persoon2){
            System.out.println("Persoon 1 is ouder dan persoon 2");
        }else if (persoon2 / 3 > persoon1) {
            System.out.println("persoon 2 is meer dan drie maal zo oud als persoon 1");
        } else if (persoon2 / 2 > persoon1) {
            System.out.println("persoon 2 is meer dan 2 maal zo oud als persoon 1");
        } else if (persoon2 > persoon1) {
            System.out.println("persoon 2 is meer dan 2 maal zo oud als persoon 1");
        } else if (persoon1 == persoon2) {
            System.out.println("persoon 1 en persoon 2 zijn even oud");
        }

    }
}
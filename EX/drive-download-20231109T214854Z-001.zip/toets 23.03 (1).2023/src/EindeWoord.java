public enum EindeWoord {
    ER,
    RE,
    IR,
    OIR
}

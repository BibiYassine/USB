import com.sun.source.tree.BreakTree;
import jdk.dynalink.linker.GuardedInvocationTransformer;

import java.beans.Introspector;
import java.util.ArrayList;

public class oef2 {
    public static void main(String[] args) {

        ArrayList<Double> reëlegetallenLijst = new ArrayList<>();
        reëlegetallenLijst.add(10.0);
        reëlegetallenLijst.add(30.0);
        reëlegetallenLijst.add(12.5);
        reëlegetallenLijst.add(2.0);
        reëlegetallenLijst.add(50.0);
        reëlegetallenLijst.add(20.0);
        reëlegetallenLijst.add(-10.0);
        ArrayList<String> bewerkingLijst = new ArrayList<>();
        bewerkingLijst.add("*");
        bewerkingLijst.add("/");
        bewerkingLijst.add("*");
        bewerkingLijst.add("a");
        bewerkingLijst.add("*");
        bewerkingLijst.add("*");
        bewerkingLijst.add("*");



        System.out.println(geefBewerking(reëlegetallenLijst,bewerkingLijst));
    }
    public static ArrayList<Integer> geefBewerking (ArrayList<Integer> reëlegetallenLijst, ArrayList<String> bewerkingLijst){
        ArrayList<Integer> uitkomstLijst = new ArrayList<>();
        for (int teller = 0; teller <= reëlegetallenLijst.size() - 1; teller++){
            for (int teller2 = 0; teller2 <= bewerkingLijst.size()-1; teller++){
                switch (){
                    case '*' -> uitkomstLijst.add(teller*2);
                    case '/' -> uitkomstLijst.add(teller/2);
                        case '²' -> uitkomstLijst.add(teller*teller);
                        case '√' -> uitkomstLijst.add(teller/teller);
                        case 'a' -> uitkomstLijst.add(teller);
                        default -> return null;
                }
            }
        }
        return uitkomstLijst;
    }
}

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        Integer[] leeftijdLijst = {10,15,100,55,32,20};
        System.out.println(geefTotaalKostPrijs(leeftijdLijst));
    }
    public static ArrayList<Integer> geefTotaalKostPrijs (Integer[] leeftijdLijst){
        ArrayList<Integer> totaal = new ArrayList<>();
        int getal = 0;
        for (int teller = 0; teller <= leeftijdLijst.length-1;teller++ ){
            if (leeftijdLijst[teller] <= 11 && leeftijdLijst[teller] >= 6 ){
                totaal.add(getal += 56);
            } else if (leeftijdLijst[teller] <=24 && leeftijdLijst[teller] >=12) {
                totaal.add(getal += 215) ;
            } else if (leeftijdLijst[teller]<=64 && leeftijdLijst[teller] >=25) {
                totaal.add(getal += 351) ;
            } else if (leeftijdLijst[teller]>=65) {
                totaal.add(getal += 56);
            }else {
                totaal.add(getal += 0);
            }
        }
        return totaal;
    }

}
import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        Scanner invoer = new Scanner(System.in);

        char voornaam1;
        char voornaam2;

        System.out.print("geef de voornaam van persoon 1: ");
        voornaam1 = invoer.nextLine().charAt(0);
        System.out.print("geef de voornaam van persoon 2: ");
        voornaam2 = invoer.nextLine().charAt(0);

        voornaam1 = Character.toUpperCase(voornaam1);
        voornaam2 = Character.toUpperCase(voornaam2);
        if (voornaam1 == 'A'){
            if (voornaam2 == 'A'){

            }else{
                System.out.println("percies één van beide namen begint met een hoofdletter A.");
            }

        } else if (voornaam2 == 'A') {
            System.out.println("percies één van beide namen begint met een hoofdletter A.");
        }


    }
}

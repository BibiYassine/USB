-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 12, 2022 at 06:57 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `20222023toets2sql`
--

-- --------------------------------------------------------

--
-- Table structure for table `artikel`
--

DROP TABLE IF EXISTS `artikel`;
CREATE TABLE IF NOT EXISTS `artikel` (
  `artikel_id` int(11) NOT NULL AUTO_INCREMENT,
  `artikel` varchar(40) NOT NULL,
  PRIMARY KEY (`artikel_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `artikel`
--

INSERT INTO `artikel` (`artikel_id`, `artikel`) VALUES
(1, 'Bic'),
(2, 'Parker'),
(3, 'Post-it'),
(4, 'Pritt'),
(5, 'A4 (500 blz)'),
(6, 'Perforator'),
(7, 'Klasseur'),
(8, 'Prikbord');

-- --------------------------------------------------------

--
-- Table structure for table `artikelprijs`
--

DROP TABLE IF EXISTS `artikelprijs`;
CREATE TABLE IF NOT EXISTS `artikelprijs` (
  `artikelprijs_id` int(11) NOT NULL AUTO_INCREMENT,
  `artikel_id` int(11) NOT NULL,
  `datum` date NOT NULL,
  `prijs` decimal(10,0) NOT NULL,
  PRIMARY KEY (`artikelprijs_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `artikelprijs`
--

INSERT INTO `artikelprijs` (`artikelprijs_id`, `artikel_id`, `datum`, `prijs`) VALUES
(1, 1, '2010-09-10', '2'),
(2, 1, '2010-09-22', '3'),
(3, 2, '2010-09-22', '10'),
(4, 3, '2010-09-21', '2'),
(5, 4, '2010-09-17', '4'),
(6, 5, '2010-09-16', '20'),
(7, 5, '2010-09-19', '21'),
(8, 6, '2010-08-18', '45'),
(9, 7, '2010-06-01', '8'),
(10, 8, '2010-01-01', '120');

-- --------------------------------------------------------

--
-- Table structure for table `factuur`
--

DROP TABLE IF EXISTS `factuur`;
CREATE TABLE IF NOT EXISTS `factuur` (
  `factuur_id` int(11) NOT NULL AUTO_INCREMENT,
  `datum` date NOT NULL,
  `betaaltermijn` int(11) NOT NULL,
  `klant_id` int(11) NOT NULL,
  PRIMARY KEY (`factuur_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `factuur`
--

INSERT INTO `factuur` (`factuur_id`, `datum`, `betaaltermijn`, `klant_id`) VALUES
(1, '2010-09-21', 30, 1),
(2, '2010-09-22', 30, 2),
(3, '2010-09-23', 30, 3);

-- --------------------------------------------------------

--
-- Table structure for table `factuurdetail`
--

DROP TABLE IF EXISTS `factuurdetail`;
CREATE TABLE IF NOT EXISTS `factuurdetail` (
  `factuurdetail_id` int(11) NOT NULL AUTO_INCREMENT,
  `factuur_id` int(11) NOT NULL,
  `artikelprijs_id` int(11) NOT NULL,
  `aantal` int(11) NOT NULL,
  PRIMARY KEY (`factuurdetail_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `factuurdetail`
--

INSERT INTO `factuurdetail` (`factuurdetail_id`, `factuur_id`, `artikelprijs_id`, `aantal`) VALUES
(1, 1, 2, 10),
(2, 1, 3, 2),
(3, 1, 8, 1),
(4, 2, 6, 1),
(5, 2, 8, 1),
(6, 2, 2, 20),
(7, 2, 5, 10),
(8, 2, 7, 1);

-- --------------------------------------------------------

--
-- Table structure for table `klant`
--

DROP TABLE IF EXISTS `klant`;
CREATE TABLE IF NOT EXISTS `klant` (
  `klant_id` int(11) NOT NULL AUTO_INCREMENT,
  `naam` varchar(40) NOT NULL,
  `adres` varchar(40) NOT NULL,
  `postcode_id` int(11) NOT NULL,
  `geslacht` tinyint(1) NOT NULL,
  PRIMARY KEY (`klant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `klant`
--

INSERT INTO `klant` (`klant_id`, `naam`, `adres`, `postcode_id`, `geslacht`) VALUES
(1, 'Jules Verne', 'Prieellaan 147', 2, 1),
(2, 'Piet Piraat', 'Hemstlei 8', 6, 1),
(3, 'Nele Omen ', 'Bozestraat 77', 7, 0),
(4, 'Griet Hansje', 'Bozestraat 77', 5, 0),
(5, 'Boke Cholles', 'Ulenlei 99', 7, 0),
(6, 'Peter Pieters', 'Bosweg 1', 4, 1),
(7, 'Peters Janstjes', 'Veroleg 4', 3, 1),
(8, 'Archimedes De Grote', 'Amerikalei 8', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `postcode`
--

DROP TABLE IF EXISTS `postcode`;
CREATE TABLE IF NOT EXISTS `postcode` (
  `postcode_id` int(11) NOT NULL AUTO_INCREMENT,
  `postcode` varchar(4) NOT NULL,
  `gemeente` varchar(40) NOT NULL,
  PRIMARY KEY (`postcode_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `postcode`
--

INSERT INTO `postcode` (`postcode_id`, `postcode`, `gemeente`) VALUES
(1, '2260', 'Hoboken'),
(2, '2000', 'Antwerpen'),
(3, '2100', 'Deurne'),
(4, '2900', 'Schoten'),
(5, '2950', 'Kapellen'),
(6, '2650', 'Edegem'),
(7, '1000', 'Brussel'),
(8, '2800', 'Mechelen');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;


SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `examen5it2021`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `tbl_gebruikers`
--

CREATE TABLE `tbl_gebruikers` (
  `leerlingnummer` int(11) NOT NULL,
  `naam` varchar(40) NOT NULL,
  `klas` varchar(5) NOT NULL,
  `wachtwoord` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `tbl_gebruikers`
--

INSERT INTO `tbl_gebruikers` (`leerlingnummer`, `naam`, `klas`, `wachtwoord`) VALUES
(1, 'Amidi Sofjan', '6IT', 'Amidi Sofjan'),
(2, 'Angellier Mathis', '6IT', 'Angellier Mathis'),
(3, 'BChristiaens Arne', '6IT', 'Christiaens Arne'),
(4, 'Doudouh Youssouf', '6IT', 'Doudouh Youssouf'),
(6, 'Elal-Lati Ilias', '6IT', 'Elal-Lati Ilias'),
(7, 'El Zarad Younes', '6IT', 'El Zarad Younes'),
(8, 'Gordon Jarno', '6IT', 'Gordon Jarno'),
(9, 'Verheijen Denzel', '6IT', 'Verheijen Denzel'),
(10, 'Badi Brahim', '5IT', 'Badi Brahim'),
(12, 'Bekaert Senne', '5IT', 'Bekaert Senne'),
(13, 'Christiaens Jonas', '5IT', 'Christiaens Jonas'),
(14, 'Doms Anton', '5IT', 'Doms Anton'),
(15, 'Fouad Wassif', '5IT', 'Fouad Wassif'),
(16, 'Heus Rune', '5IT', 'Heus Rune'),
(17, 'Matthys Cas', '5IT', 'Matthys Cas'),
(18, 'Mergaerts Lennard', '5IT', 'Mergaerts Lennard'),
(19, 'Moons Ruben', '5IT', 'Moons Ruben'),
(20, 'Oost Kieran', '5IT', 'Oost Kieran'),
(21, 'Scott Philip', '5IT', 'Scott Philip'),
(22, 'Szeredi Eva-Veronica', '5IT', 'Szeredi Eva-Veronica'),
(23, 'Uyttebroeck Noah', '5IT', 'Uyttebroeck Noah'),
(24, 'Arys Nicolaas', '6BE', 'Arys Nicolaas'),
(25, 'Cleynhens Rikkert', '6BE', 'Cleynhens Rikkert'),
(26, 'Decroo Robbe', '6BE', 'Decroo Robbe'),
(27, 'Eestermans Niels', '6BE', 'Eestermans Niels'),
(28, 'Fostier Daan', '6BE', 'Fostier Daan'),
(29, 'Heus Yente', '6BE', 'Heus Yente'),
(30, 'Klinkers Andy', '6BE', 'Klinkers Andy'),
(31, 'Mergaerts Anton', '6BE', 'Mergaerts Anton'),
(32, 'Vansteyvoort Willem', '6BE', 'Vansteyvoort Willem'),
(33, 'Velkeneers  Jonathan', '6BE', 'Velkeneers  Jonathan'),
(34, 'Wijns Gerrit', 'lkr', 'Wijns Gerrit');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `tbl_gemaakteoefening`
--

CREATE TABLE `tbl_gemaakteoefening` (
  `volgnummergemaakteoefening` int(11) NOT NULL,
  `gebruikersnummer` int(11) NOT NULL,
  `antwoord` int(11) NOT NULL,
  `gemaaktop` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `tbl_gemaakteoefening`
--

INSERT INTO `tbl_gemaakteoefening` (`volgnummergemaakteoefening`, `gebruikersnummer`, `antwoord`, `gemaaktop`) VALUES
(270, 5, -15, '2019-06-14'),
(174, 5, 1, '2019-06-14'),
(276, 11, 9, '2019-06-14'),
(229, 3, 240, '2019-06-14');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `tbl_oefeningen`
--

CREATE TABLE `tbl_oefeningen` (
  `oefeningnummer` int(11) NOT NULL,
  `oefening` varchar(10) NOT NULL,
  `oplossing` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `tbl_oefeningen`
--

INSERT INTO `tbl_oefeningen` (`oefeningnummer`, `oefening`, `oplossing`) VALUES
(1, '4+9', 13),
(2, '3 + 12', 15),
(3, '19 - 6', 13),
(4, '6 * 4', 24),
(5, '12 + 3', 15),
(6, '10 - 18', -8),
(7, '8 * 2', 16),
(8, '9 + 12', 21),
(9, '7 - 12', -5),
(10, '3 * 13', 39),
(11, '10 + 11', 21),
(12, '13 - 5', 8),
(13, '18 * 4', 72),
(14, '7 + 5', 12),
(15, '16 - 2', 14),
(16, '2 * 19', 38),
(17, '14 + 9', 23),
(18, '2 - 10', -8),
(19, '4 * 7', 28),
(20, '1 + 8', 9),
(21, '2 - 20', -18),
(22, '14 * 5', 70),
(23, '11 + 1', 12),
(24, '15 - 19', -4),
(25, '3 * 11', 33),
(26, '4 + 2', 6),
(27, '15 - 3', 12),
(28, '19 * 8', 152),
(29, '17 + 20', 37),
(30, '7 - 4', 3),
(31, '15 * 2', 30),
(32, '1 + 7', 8),
(33, '7 - 19', -12),
(34, '17 * 14', 238),
(35, '5 + 5', 10),
(36, '19 - 5', 14),
(37, '13 * 18', 234),
(38, '13 + 14', 27),
(39, '12 - 8', 4),
(40, '2 * 17', 34),
(41, '5 + 14', 19),
(42, '6 - 19', -13),
(43, '3 * 15', 45),
(44, '19 + 1', 20),
(45, '12 - 11', 1),
(46, '2 * 5', 10),
(47, '15 + 6', 21),
(48, '15 - 10', 5),
(49, '18 * 1', 18),
(50, '14 + 11', 25),
(51, '2 - 10', -8),
(52, '8 * 2', 16),
(53, '6 + 12', 18),
(54, '19 - 20', -1),
(55, '19 * 5', 95),
(56, '11 + 13', 24),
(57, '8 - 12', -4),
(58, '16 * 19', 304),
(59, '9 + 13', 22),
(60, '9 - 12', -3),
(61, '6 * 4', 24),
(62, '13 + 15', 28),
(63, '3 - 5', -2),
(64, '18 * 1', 18),
(65, '3 + 1', 4),
(66, '11 - 12', -1),
(67, '10 * 2', 20),
(68, '15 + 18', 33),
(69, '11 - 11', 0),
(70, '18 * 6', 108),
(71, '11 + 5', 16),
(72, '8 - 17', -9),
(73, '2 * 10', 20),
(74, '7 + 6', 13),
(75, '18 - 4', 14),
(76, '13 * 18', 234),
(77, '9 + 4', 13),
(78, '16 - 16', 0),
(79, '8 * 7', 56),
(80, '10 + 19', 29),
(81, '10 - 14', -4),
(82, '4 * 7', 28),
(83, '19 + 1', 20),
(84, '20 - 10', 10),
(85, '7 * 1', 7),
(86, '4 + 7', 11),
(87, '1 - 14', -13),
(88, '17 * 13', 221),
(89, '18 + 9', 27),
(90, '12 - 6', 6),
(91, '10 * 3', 30),
(92, '12 + 10', 22),
(93, '20 - 17', 3),
(94, '14 * 20', 280),
(95, '4 + 5', 9),
(96, '6 - 8', -2),
(97, '12 * 16', 192),
(98, '5 + 11', 16),
(99, '20 - 19', 1),
(100, '20 * 9', 180),
(101, '14 + 19', 33),
(102, '18 - 3', 15),
(103, '19 * 6', 114),
(104, '12 + 19', 31),
(105, '19 - 20', -1),
(106, '2 * 6', 12),
(107, '10 + 16', 26),
(108, '13 - 16', -3),
(109, '3 * 8', 24),
(110, '17 + 16', 33),
(111, '12 - 19', -7),
(112, '8 * 8', 64),
(113, '9 + 8', 17),
(114, '18 - 15', 3),
(115, '9 * 11', 99),
(116, '14 + 11', 25),
(117, '19 - 12', 7),
(118, '19 * 9', 171),
(119, '12 + 5', 17),
(120, '8 - 11', -3),
(121, '17 * 10', 170),
(122, '14 + 2', 16),
(123, '5 - 7', -2),
(124, '5 * 6', 30),
(125, '14 + 2', 16),
(126, '2 - 19', -17),
(127, '16 * 5', 80),
(128, '6 + 19', 25),
(129, '9 - 6', 3),
(130, '12 * 1', 12),
(131, '13 + 12', 25),
(132, '1 - 4', -3),
(133, '7 * 11', 77),
(134, '16 + 1', 17),
(135, '13 - 11', 2),
(136, '4 * 14', 56),
(137, '3 + 13', 16),
(138, '14 - 2', 12),
(139, '13 * 8', 104),
(140, '6 + 2', 8),
(141, '13 - 10', 3),
(142, '19 * 10', 190),
(143, '10 + 14', 24),
(144, '2 - 15', -13),
(145, '11 * 15', 165),
(146, '13 + 9', 22),
(147, '7 - 3', 4),
(148, '15 * 17', 255),
(149, '16 + 10', 26),
(150, '1 - 6', -5),
(151, '13 * 9', 117),
(152, '16 + 3', 19),
(153, '4 - 17', -13),
(154, '3 * 13', 39),
(155, '3 + 4', 7),
(156, '20 - 17', 3),
(157, '11 * 2', 22),
(158, '17 + 15', 32),
(159, '17 - 9', 8),
(160, '12 * 13', 156),
(161, '15 + 14', 29),
(162, '6 - 20', -14),
(163, '8 * 4', 32),
(164, '9 + 9', 18),
(165, '15 - 10', 5),
(166, '15 * 4', 60),
(167, '12 + 16', 28),
(168, '16 - 5', 11),
(169, '9 * 7', 63),
(170, '19 + 5', 24),
(171, '15 - 16', -1),
(172, '4 * 4', 16),
(173, '8 + 10', 18),
(174, '9 - 9', 0),
(175, '16 * 15', 240),
(176, '7 + 2', 9),
(177, '4 - 17', -13),
(178, '8 * 1', 8),
(179, '13 + 6', 19),
(180, '12 - 13', -1),
(181, '14 * 16', 224),
(182, '11 + 2', 13),
(183, '11 - 18', -7),
(184, '7 * 9', 63),
(185, '20 + 17', 37),
(186, '20 - 8', 12),
(187, '17 * 15', 255),
(188, '18 + 15', 33),
(189, '6 - 5', 1),
(190, '11 * 7', 77),
(191, '13 + 9', 22),
(192, '14 - 20', -6),
(193, '6 * 4', 24),
(194, '18 + 6', 24),
(195, '3 - 4', -1),
(196, '7 * 12', 84),
(197, '16 + 14', 30),
(198, '8 - 10', -2),
(199, '2 * 12', 24),
(200, '19 + 4', 23),
(201, '5 - 19', -14),
(202, '9 * 20', 180),
(203, '19 + 2', 21),
(204, '5 - 8', -3),
(205, '1 * 18', 18),
(206, '19 + 12', 31),
(207, '7 - 19', -12),
(208, '2 * 3', 6),
(209, '18 + 11', 29),
(210, '18 - 12', 6),
(211, '2 * 20', 40),
(212, '11 + 10', 21),
(213, '8 - 19', -11),
(214, '17 * 4', 68),
(215, '10 + 15', 25),
(216, '15 - 3', 12),
(217, '15 * 4', 60),
(218, '12 + 12', 24),
(219, '1 - 11', -10),
(220, '2 * 17', 34),
(221, '4 + 4', 8),
(222, '14 - 12', 2),
(223, '16 * 3', 48),
(224, '5 + 20', 25),
(225, '19 - 14', 5),
(226, '6 * 1', 6),
(227, '9 + 18', 27),
(228, '19 - 9', 10),
(229, '20 * 12', 240),
(230, '18 + 3', 21),
(231, '19 - 9', 10),
(232, '14 * 4', 56),
(233, '1 + 10', 11),
(234, '11 - 11', 0),
(235, '6 * 7', 42),
(236, '1 + 14', 15),
(237, '14 - 3', 11),
(238, '17 * 7', 119),
(239, '1 + 14', 15),
(240, '17 - 11', 6),
(241, '10 * 8', 80),
(242, '17 + 10', 27),
(243, '4 - 1', 3),
(244, '10 * 19', 190),
(245, '3 + 9', 12),
(246, '5 - 13', -8),
(247, '8 * 18', 144),
(248, '5 + 4', 9),
(249, '5 - 5', 0),
(250, '16 * 11', 176),
(251, '17 + 20', 37),
(252, '6 - 7', -1),
(253, '16 * 6', 96),
(254, '19 + 1', 20),
(255, '18 - 8', 10),
(256, '19 * 9', 171),
(257, '3 + 18', 21),
(258, '7 - 8', -1),
(259, '14 * 17', 238),
(260, '12 + 5', 17),
(261, '18 - 4', 14),
(262, '20 * 19', 380),
(263, '17 + 1', 18),
(264, '6 - 7', -1),
(265, '12 * 12', 144),
(266, '11 + 16', 27),
(267, '7 - 12', -5),
(268, '12 * 20', 240),
(269, '11 + 7', 18),
(270, '2 - 17', -15),
(271, '12 * 6', 72),
(272, '6 + 12', 18),
(273, '20 - 5', 15),
(274, '20 * 4', 80),
(275, '3 + 5', 8),
(276, '15 - 6', 9),
(277, '7 * 18', 126),
(278, '20 + 1', 21),
(279, '9 - 5', 4),
(280, '9 * 18', 162),
(281, '13 + 4', 17),
(282, '7 - 19', -12),
(283, '2 * 2', 4),
(284, '6 + 15', 21),
(285, '12 - 7', 5),
(286, '12 * 16', 192),
(287, '20 + 15', 35),
(288, '20 - 4', 16),
(289, '19 * 9', 171),
(290, '1 + 6', 7),
(291, '19 - 3', 16),
(292, '6 * 19', 114),
(293, '12 + 18', 30),
(294, '11 - 3', 8),
(295, '18 * 18', 324),
(296, '16 + 20', 36),
(297, '18 - 15', 3),
(298, '3 * 12', 36),
(299, '15 + 11', 26),
(300, '6 - 9', -3),
(301, '15 * 1', 15),
(302, '16 + 19', 35),
(303, '12 - 18', -6),
(304, '3 * 12', 36),
(305, '14 + 17', 31),
(306, '16 - 13', 3),
(307, '20 * 7', 140),
(308, '11 + 15', 26),
(309, '8 - 16', -8),
(310, '7 * 12', 84),
(311, '8 + 12', 20),
(312, '10 - 5', 5),
(313, '10 * 6', 60),
(314, '10 + 2', 12),
(315, '18 - 14', 4),
(316, '4 * 16', 64),
(317, '8 + 9', 17),
(318, '2 - 18', -16);

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `tbl_gebruikers`
--
ALTER TABLE `tbl_gebruikers`
  ADD PRIMARY KEY (`leerlingnummer`);

--
-- Indexen voor tabel `tbl_gemaakteoefening`
--
ALTER TABLE `tbl_gemaakteoefening`
  ADD PRIMARY KEY (`volgnummergemaakteoefening`);

--
-- Indexen voor tabel `tbl_oefeningen`
--
ALTER TABLE `tbl_oefeningen`
  ADD PRIMARY KEY (`oefeningnummer`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `tbl_gebruikers`
--
ALTER TABLE `tbl_gebruikers`
  MODIFY `leerlingnummer` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT voor een tabel `tbl_oefeningen`
--
ALTER TABLE `tbl_oefeningen`
  MODIFY `oefeningnummer` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=319;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

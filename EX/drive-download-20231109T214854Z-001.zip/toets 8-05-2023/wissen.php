<?php
include "connect.php";
echo"<h1>Record verwijderen</h1>";
$Sql = "DELETE FROM tblpunt WHERE volgnummer=".$_GET['tewissen'];
if($Mysqli->query($Sql)){
    echo"Het is succesvol gewist.";
}else{
    echo"Error record wissen:". $Mysqli->error;
}
$Mysqli->close();
print "<br><a href='index.php'>Ga terug</a>";

?>
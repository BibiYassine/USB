<?php
include "connect.php";
$Sql = "select volgnummer, leerlingnummer, vaknaam, score, maximum from tblpunt, tblgebruiker";
$resultaat = $Mysqli->query($Sql);
echo"<table>";


echo "</table>";
print "<a href=wissen.php>wissen</a>";
echo"<br>";
print "<a href=wijzigen.php>wijzigen</a>";
echo"<br>";
print "<a href=toevoegen.php>Voeg een record toe</a>";
echo"<br>";
print "<a href=score.php>krijg gemiddelde score</a>";


?>
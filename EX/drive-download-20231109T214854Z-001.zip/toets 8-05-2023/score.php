<?php

include "connect.php";

$score = $_POST['score'];
$maximum = $_POST['maximum'];



?>
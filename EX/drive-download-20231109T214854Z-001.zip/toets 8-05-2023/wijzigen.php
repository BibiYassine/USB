<?php
include "connect.php";
echo '<h1>Tabel aanpassen</h1>';
if (isset($_POST['wijzigen']))
{
    $volgnummer = $_POST['volgnummer'];
    $leerlingnummer = $_POST['leerlingnummer'];
    $vaknaam = $_POST['vaknaam'];
    $score = $_POST['score'];
    $maximum = $_POST['maximum'];
    $Sql = "UPDATE tblpunt SET leerlingnummer = '".$leerlingnummer."',vaknaam = '".$vaknaam."',score = '".$score."',maximum = '".$maximum."'WHERE volgnummer=".$volgnummer;
    if($Mysqli->query($Sql)){
        echo"Het is succesvol gewijzigd.";
    }else {
        echo "Error record wijzigen:" . $Mysqli->error;
    }
    print "<br><a href='index.php'>Ga terug</a>";
}
else
{
    $Sql = "SELECT * FROM tblpunt where volgnummer=".$_GET['teveranderen'];
    $resultaat = $Mysqli->query($Sql);
    $row = $resultaat->fetch_assoc();
    echo '<table>
            <form action="wijzigen.php" method="post">
            <tr><td> Volgnummer </td><td>'.$row['volgnummer'].'<input type="hidden" name="volgnummer" value="'.$row['volgnummer'].'"></td></tr>
            <tr><td> leerlingnummer </td><td><input type="text" name="leerlingnummer" value="'.$row['leerlingnummer'].'"></td></tr>
            <tr><td> vaknaam </td><td><input type="text" name="vaknaam" value="'.$row["vaknaam"].'"></td></tr>
            <tr><td> score </td><td><input type="text" name="score" value="'.$row['score'].'"></td></tr>
            <tr><td> maximum </td><td><input type="text" name="maximum" value="'.$row['maximum'].'"></td></tr>   
            <tr><td colspan = 2><input type="submit" value="wijzigen" name="veranderen"></rd></tr>
        </form>
        </table>';
}
$Mysqli->close();
?>
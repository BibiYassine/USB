<?php
$Mysqli = new mysqli("", "root", "", "dbpuntenboek");

if ($Mysqli->connect_errno) {
    print "Kon niet naar Mysql gaan: (" .$Mysqli->connect_errno. ")" .$Mysqli->connect_errno;
}
?>
<?php
include "connect.php";
echo "<h1>record Toevoegen</h1>";
echo '<table>
            <form action="toevoegen.php" method="post">
            <tr><td> leerlingnummer </td><td><input type="text" name="leerlingnummer"></td></tr>
                        <p>
                        Vaknaam
                        <select name="vaknaam">
                        <option value="Wiskunde">Wiskunde</option>
                        <option value="Databases">Databases</option>
                        <option value="Software">Software</option>
                        </select>
                        </p>
            <tr><td> score </td><td><input type="text" name="score" </td></tr>
            <tr><td> maximum </td><td><input type="text" name="maximum"</td></tr>
            <tr><td colspan=2><input type="submit" value="Aanpassen" name="submit"></td></tr>
        </form>
        </table>';
if (isset($_POST['submit'])) {
    $leerlingnummer = $_POST['leerlingnummer'];
    $vaknaam = $_POST['vaknaam'];
    $score = $_POST['score'];
    $maximum = $_POST['maximum'];
    include "connect.php";
    $Sql = "INSERT INTO tblpunt (leerlingnummer, vaknaam, score, maximum) VALUES ('" . $leerlingnummer . "','" . $vaknaam . "','" . $score . "','" . $maximum . "')";
    if ($Mysqli->query($Sql)) {
        echo "Het is succesvol toegevoegd. <br>";
    } else {
        echo "Error record toevoegen:" . $Mysqli->error."<br>";
    }
    $Mysqli->close();
}
print "<br><a href='index.php'>Ga terug</a>";
?>
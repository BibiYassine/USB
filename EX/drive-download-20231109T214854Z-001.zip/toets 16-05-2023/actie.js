function toonAantal(idexemplaren, iduitgave){
	let exemplaren = document.getElementById(idexemplaren).value;
	let text
	let uitgave = document.getElementById(iduitgave);
	text = "Je hebt " + exemplaren + " exemplaren besteld"	
	uitgave.textContent = text ;
}
<?php
session_start();
?>
<?php
if(isset($_POST["knop"])){
    print "<br> Voor te bestellen <a href='drankverbruik.php'> klik hier</a>";
}else{
    echo'
    <table>
        <form method="post" action="rekening.php">
        <tr><td>naam</td><td><input type="text" id="naam"></td></tr>
        <tr><td><input type="submit" id="knop" value="verdergaan"></td></tr>
        </form>
    </table>';
}

?>

<?php
session_start();
?>
<?php
print "Rekening van " .$_POST["naam"];
echo'
    <table>
        <form method="post" action="drankverbruik.php">
        <select>  
  <option value="Select">Select</option>}  
  <option value="Vineet">Vineet Saini</option>  
  <option value="Sumit">Sumit Sharma</option>  
  <option value="Dorilal">Dorilal Agarwal</option>  
  <option value="Omveer">Omveer Singh</option>  
  <option value="Rohtash">Rohtash Kumar</option>  
  <option value="Maneesh">Maneesh Tewatia</option>  
  <option value="Priyanka">Priyanka Sachan</option>  
  <option value="Neha">Neha Saini</option>  
</select> 
        <tr><td><input type="number" id="aantal"></td></tr>
        <tr><td>Aantal</td><td><input type="submit" id="knop" value="verdergaan"></td></tr>
        </form>
    </table>';
?>

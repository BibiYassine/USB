<?php
session_start();
?>
<!DOCTYPE html>
<html>
<body>
<?php
session_destroy();
//de rekening
?>
</body>
</html>
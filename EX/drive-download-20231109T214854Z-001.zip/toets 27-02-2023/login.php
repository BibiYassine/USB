<?php
session_start()
?>
<?php

print "<br> 1. Open een nieuwe rekening: <a href='rekening.php'> klik hier</a>";
print "<br> 2. Drankverbruik registreren: <a href='drankverbruik.php'> klik hier</a>";
print "<br> 3. Afrekenen: <a href='afrekenen.php'> klik hier</a>";

?>
<?php
session_start();
?>
<?php
$_SESSION["aantalWI"] = 0;
$_SESSION["aantalP"] = 0;
$_SESSION["aantalWA"] = 0;
$_SESSION["aantalC"] = 0;

print  "<br>Rekening van " .$_SESSION["naam"];

echo'
    <table>
        <form method="post" action="drankverbruik.php">
        <br><select name="drank"> 
  <option id="cola">cola</option>  
  <option id="water">water </option>  
  <option id="pint">pint</option>  
  <option id="wijn">wijn</option>  
</select> 
        <tr><td><input type="number" id="aantal"></td></tr>
        <tr><td>Aantal</td><td><input type="submit" id="knop" value="verdergaan"></td></tr>
        </form>
    </table>';

if($_POST["cola"]){
    $_SESSION["aantalC"] += $_POST["aantal"];
}elseif($_POST["wijn"]){
    $_SESSION["aantalWI"] += $_POST["aantal"];
}elseif($_POST["pint"]){
    $_SESSION["aantalP"] += $_POST["aantal"];
}elseif($_POST["water"]){
    $_SESSION["aantalWA"] += $_POST["aantal"];
}




print"Ga door na je de naam hebt ingegeven <a href='afrekenen.php'>Klik hier</a>"

?>

<?php
session_start();
?>
<!DOCTYPE html>
<html>
<body>
<?php
$som = 0;

session_destroy();
print "<br>Rekening van " .$_SESSION["naam"];
print"<br>Cola: " .$_SESSION["aantalC"]. " aan 2 euro: " .$_SESSION["aantalC"]*2;
print"<br>Water: " .$_SESSION["aantalWA"]. " aan 2 euro: " .$_SESSION["aantalWA"]*2;
print"<br>Pint: " .$_SESSION["aantalP"]. " aan 2,5 euro: " .$_SESSION["aantalP"]*2.5;
print"<br>Wijn: " .$_SESSION["aantalWI"]. " aan 4 euro: " .$_SESSION["aantalWI"]*4;
$som = $_SESSION["aantalC"]*2+$_SESSION["aantalWA"]*2+$_SESSION["aantalP"]*2.5+$_SESSION["aantalWI"]*4;
print"<br>totaal: " .$som. " euro";
?>
</body>
</html>
<?php
session_start();
?>
<!DOCTYPE html>
<html>
<body>
<?php
    echo'
                    <table>
                        <form method="post" action="rekening.php">
                            <tr><td>Geef je naam</td><td><input type="text" name="naam"></td></tr>
                        </form>                
                    </table>';
print"Ga door na je de naam hebt ingegeven <a href='drankverbruik.php'>Klik hier</a>"
?>

</body>
</html>

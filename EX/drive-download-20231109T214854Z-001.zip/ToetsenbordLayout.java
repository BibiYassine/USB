public enum ToetsenbordLayout {
    QUERTY,
    AZERTY,

}

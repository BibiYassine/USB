import java.math.BigDecimal;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {


        TeamCategorieën[][] teamCategorieëns = {
                {TeamCategorieën.MADOAFPRO},
                {TeamCategorieën.ACBA},
                {TeamCategorieën.ACBA},
                {TeamCategorieën.SECOND},
                {TeamCategorieën.PROFBA},
                {TeamCategorieën.MADOAFPRO},
                {TeamCategorieën.PROFBA},
                {TeamCategorieën.SECOND},
                {TeamCategorieën.MADOAFPRO},
                {TeamCategorieën.MADOAFPRO},
                {TeamCategorieën.ACBA},
                {TeamCategorieën.SECOND},
                {TeamCategorieën.SECOND},
                {TeamCategorieën.PROFBA},
                {TeamCategorieën.PROFBA},
                {TeamCategorieën.ACBA},
        };


        String[][] TeamnamenMatrix = {
                {"Lords of the ring"},
                {"Stack overflow Error"},
                {"De paljaskes"},
                {"Alt f4"},
                {"Turning"},
                {"Synergie"},
                {"Waterkokers"},
                {"JavaFX"},
                {"HackerMan"},
                {"Error 404"},
                {"Robots"},
                {"Ctrl"},
                {"Dynamic programmers"},
                {"The Matrix Bubbles"},
                {"Bits please"},
                {"De schakels"},
        };

        BigDecimal[][] GeldPrijsLijst = {
                {BigDecimal.valueOf(300.35)},
                {BigDecimal.valueOf(510.85)},
                {BigDecimal.valueOf(1000.00)},
                {BigDecimal.valueOf(223.18)},
                {BigDecimal.valueOf(0.00)},
                {BigDecimal.valueOf(0.00)},
                {BigDecimal.valueOf(1000.50)},
                {BigDecimal.valueOf(500.10)},
                {BigDecimal.valueOf(600.30)},
                {BigDecimal.valueOf(518.77)},
                {BigDecimal.valueOf(0.00)},
                {BigDecimal.valueOf(1500.58)},
                {BigDecimal.valueOf(0.00)},
                {BigDecimal.valueOf(300.25)},
                {BigDecimal.valueOf(400.88)},
                {BigDecimal.valueOf(1230.98)},
        };

        System.out.println(GewonnenBedrag(GeldPrijsLijst, TeamnamenMatrix, teamCategorieëns));

    }


    public static int GewonnenBedrag(BigDecimal[][] GeldPrijsMatrix, String[][] TeamnamenMatrix, TeamCategorieën teamCategorieën) {
        int i = 0;
        ArrayList<String> gewonnenteam = new ArrayList<String>();
        for (int richting = 0; richting <= teamCategorieën.length; richting++) {
            for (int team = 0; team <= TeamnamenMatrix.length; team++) {
                for (int geld = 0; geld <= GeldPrijsMatrix.length; geld++) {

                    if (geld > i) {
                        ArrayList<String> gewonnenTeam = new ArrayList<String>();
                        gewonnenTeam.get(richting);
                        i = geld;
                    } else {

                    }

                }
            }
        }
        return gewonnenteam;
    }

}
public enum TeamCategorieën {
    SECOND,
    PROFBA,
    ACBA,
    MADOAFPRO
}

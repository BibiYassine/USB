
document.addEventListener("DOMContentLoaded", function() {
	
	// Lijst met willekeurige woorden
	var randomHoek = ["awesome", "cool", "scary", "fantastisch", "stinky", "cold"];
	
	// Kies een willekeurig woord
	var chosenHoek = Math.floor(Math.random() * randomHoek.length);
	
	// Voeg het gekozen woord toen aand de HTML-tag met id="randomText" 
	document.getElementById("hoek").innerHTML = randomHoek[chosenHoek];
	
});



document.addEventListener("DOMContentLoaded", function() {
	
	// Lijst met willekeurige woorden
	var randomWords = ["normal", "slow", "aggressive", "calm", "in silence", "cold"];
	
	// Kies een willekeurig woord
	var chosenWords = Math.floor(Math.random() * randomWords.length);
	
	// Voeg het gekozen woord toen aand de HTML-tag met id="randomText" 
	document.getElementById("snelheid").innerHTML = randomWords[chosenWords];
	
});




document.addEventListener("DOMContentLoaded", function() {
	
	// Lijst met willekeurige woorden
	var randomWords = ["daylight", "moonlight", "flashlight"];
	
	// Kies een willekeurig woord
	var chosenWords = Math.floor(Math.random() * randomWords.length);
	
	// Voeg het gekozen woord toen aand de HTML-tag met id="randomText" 
	document.getElementById("licht").innerHTML = randomWords[chosenWords];
	
});

document.addEventListener("DOMContentLoaded", function() {
	
	// Lijst met willekeurige woorden
	var randomWords = ["hated", "adored"];
	
	// Kies een willekeurig woord
	var chosenWords = Math.floor(Math.random() * randomWords.length);
	
	// Voeg het gekozen woord toen aand de HTML-tag met id="randomText" 
	document.getElementById("gevoel").innerHTML = randomWords[chosenWords];
	
});


document.addEventListener("DOMContentLoaded", function() {
	var randomImage = ["images/GOBLIN.png", "images/berg.png", "images/shelter.png"];
  
	// Kies een willekeurige foto
	var chosenImage = Math.floor(Math.random() * randomImage.length);
  
	// Voeg het gekozen woord toen aan de HTML-tag met class "tekstje"
	document.querySelector(".tekstje").style.backgroundImage = "url(" + randomImage[chosenImage] + ")";
  });
  

document.addEventListener("DOMContentLoaded", function() {
    
    // Lijst met willekeurige kleuren
    var randomColors = ["red", "green", "blue", "orange", "purple", "yellow"];
    
    // Selecteer alle elementen met de klasse "random-word"
    var randomWordElements = document.getElementsByClassName("random-word");
    
    // Loop door de geselecteerde elementen en voeg een willekeurige kleur toe
    for (var i = 0; i < randomWordElements.length; i++) {
      var randomColor = randomColors[Math.floor(Math.random() * randomColors.length)];
      randomWordElements[i].style.color = randomColor;
    }





	    // voer code uit als je op de knop klikt
	document.getElementById("toonVerhaal").addEventListener("click", function() {
    
		// test of de knop werkt
	console.log('Toon verhaal');

		// verwijder en voeg de .verborgen class toe
	document.getElementById("formulier").classList.add("verborgen");
	document.getElementById("verhaal").classList.remove("verborgen");

	let naam = document.getElementById("naamTextfield").value;
	console.log(naam);
	document.getElementById("name").innerHTML = naam;



});


});

let number = Math.floor(Math.random() * 10);

document.getElementById("number").innerHTML = number


    



let naam = document.getElementById("naamTextfield").value;
console.log(naam);






